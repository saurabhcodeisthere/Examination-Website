function taking_values(x)
{
	var teacher="tc";
	var student="sd";
	if(student===x)
	{
		location.href="Student_Login.html";
	}
	else
	{
		location.href="Teachers_Login.html";
	}
}