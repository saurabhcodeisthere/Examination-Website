function taking_values(e)
{
	
	var email=document.getElementById("text1").value;
    var db=firebase.database().ref();
}