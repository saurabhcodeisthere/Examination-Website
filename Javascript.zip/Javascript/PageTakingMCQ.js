$("#submit").click(function(){
    $.post($("#myform").attr("action"),$("#myform :input").serializeArray());
    clearInput();
});

$("#myfrom").submit(function()
{
  return false;
});

function clearInput()
{
  $("#myfrom:input").each(function ()
  {
      $(this).val('');
  });
}