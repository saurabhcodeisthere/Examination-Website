function taking_values()
{
		var login=document.getElementById("text1").value;
		var password=document.getElementById("text2").value;
		var check=checking_values(login,password);
		if(check==false)
		{
			location.href="Teachers_Login.html";
			return false;
		}
		else
			return true;
}
function checking_values(x,y)
{
	var login=x;
	var password=y;
	var regex= /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?!.*\s).{4,13}$/;
	if(login.match("@"))
	{
		if(regex.test(password))
		{
			return true;
		}
		else
		{
			return false;
		}	
	}
	else
	{
		return false;
	}	
}