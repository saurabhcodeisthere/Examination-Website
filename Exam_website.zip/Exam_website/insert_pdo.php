<?php
	include "index_pdo.php";
	$fname=$_POST['fname'];
	$lname=$_POST["lname"];
	$email=$_POST["email"];
	$password=$_POST["pass"];
	$gender=$_POST["gender"];
	$date=$_POST["date"];
	$city=$_POST["city"];
	$state=$_POST["state"];
	$country=$_POST["country"];
	$contact=$_POST["contact"];
	$address=$_POST["address"];
	global $conn;
	if(isset($_POST['submit']))
	{
		$stmt = $conn->prepare("INSERT INTO details (Fname,Lname,Email,Password,Gender,Date,Address,City,State,Country,Phone) VALUES (:fname,:lname,:email,:password,:gender,:date,:address,:city,:state,:country,:contact)");
		echo $conn -> error;
    	$stmt->bind_param(:fname,$fname);
    	$stmt->bind_param(:lname,$lname);
    	$stmt->bind_param(:email,$email);
    	$stmt->bind_param(:password,$password);
    	$stmt->bind_param(:gender,$gender);
    	$stmt->bind_param(:date,$date);
    	$stmt->bind_param(:address,$address);
    	$stmt->bind_param(:city,$city);
    	$stmt->bind_param(:state,$state);
    	$stmt->bind_param(:country,$country);
    	$stmt->bind_param(:contact,$contact);
    	$stmt->execute();
    	$stmt->close();
	}
	else
	{
		echo "Data not reached.Enter again.";
	}
	if(isset($_POST['submit']))
	{
		$stmt = $conn->prepare("INSERT INTO login (Email,Password) VALUES (:email,:password)");
    	$stmt->bind_param(:email,$email);
    	$stmt->bind_param(:password,$password);
    	$stmt->execute();
    	$stmt->close();
	}
	else
	{
		echo "Data not reached.Enter again.";
	}

?>