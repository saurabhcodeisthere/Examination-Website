<?php
		 header("Content-Type: image/png");
		 require "vendor/autoload.php";
		 use vendor\Endroid\QrCode\ErrorCorrectionLevel;
		 use Endroid\QrCode\LabelAlignment;
		 use Endroid\QrCode\QrCode;
		 use Endroid\QrCode\Response\QrCodeResponse;
		 require('PHPMailer-master/src/PHPMailer.php');
		 require('PHPMailer-master/src/SMTP.php');
		 require('PHPMailer-master/src/Exception.php');
		 include('index.php');

		 $email=$_POST["login"];
		 $password=$_POST["password"];
		 global $conn;
		 global $pass;
		 $date=date("d-m-y");
		 $day=date("l");
		 $time=("H:i:sa");
		 $enc=$date." ".$day." ".$time."Email-".$email;
		 $value=md5($email);
		 if(isset($_POST['submit']))
		 {
		 	$stmt=$conn->prepare("SELECT Password from hoteldetails where Email=?");
		 	$stmt->bind_param("s",$email);
		 	$stmt->execute();
		 	$stmt->store_result();
		 	$stmt->bind_result($Password);
		 	$stmt->fetch();
		 	$pass=$Password;
		 }
		 else
		 {
		 	echo "Data connection failed.";
		 }
		 if($pass==$password)
		 {
		 	echo "Welcome";
		 	$qrCode = new QrCode($value);
		 	$qrCode->setSize(300);
		 	$qrCode->writeFile(__DIR__.'/qrcode.png');

		 	$mail = new PHPMailer\PHPMailer\PHPMailer();
		 	$mail -> IsSMTP();
			$mail->SMTPDebug = 4;
			$mail->SMTPAuth = true;
			$mail ->SMTPSecure='tls';
			$mail ->Host='smtp.gmail.com';
			$mail ->Port='587';
			$mail-> isHTML();
			$mail->Username='saurabh.2017@vitstudent.ac.in';
			$mail->Password='saurabh12345';
			$mail-> SetFrom('saurabh.2017@vitstudent.ac.in');
			$mail->addAddress($email);
			$mail->Subject='Sending mail';
			$mail->Body='Hi! This is my first e-mail sending through php';
			$file_to_attach = 'qrcode.png';
			$mail->AddAttachment( $file_to_attach , 'Qr Code');
			$mail->SMTPDebug = 0;
			$mail->send();
			header("Location:../html/secondHotelLogin.html");

		 }
		 else
		 	header("Location:../html/oops.html");
		 	
		?>


