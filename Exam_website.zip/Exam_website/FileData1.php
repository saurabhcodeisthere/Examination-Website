<?php
	$var1=$_POST["keyword1"];
	$var2=$_POST["keyword2"];
	$var3=$_POST["keyword3"];
	$var4=$_POST["keyword4"];
	$var5=$_POST["keyword5"];
	$content=file_get_contents("checking.txt");
	$count1=substr_count($content,$var1);
	$count2=substr_count($content,$var2);
	$count3=substr_count($content,$var3);
	$count4=substr_count($content,$var4);
	$count5=substr_count($content,$var5);
	echo '<table border="0" cellspacing="2" cellpadding="2"> 
      <tr> 
          <td> <font face="Arial">Word</font> </td> 
          <td> <font face="Arial">Frequency</font> </td> 
      </tr>';

       echo '<tr> 
                  <td>'.$var1.'</td> 
                  <td>'.$count1.'</td>  
              </tr>';
       echo '<tr> 
                  <td>'.$var2.'</td> 
                  <td>'.$count2.'</td>  
              </tr>';
       echo '<tr> 
                  <td>'.$var3.'</td> 
                  <td>'.$count3.'</td>  
              </tr>';
       echo '<tr> 
                  <td>'.$var4.'</td> 
                  <td>'.$count4.'</td>  
              </tr>';
       echo '<tr> 
                  <td>'.$var5.'</td> 
                  <td>'.$count5.'</td>  
              </tr>';
<?