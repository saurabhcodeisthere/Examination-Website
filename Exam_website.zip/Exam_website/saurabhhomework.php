<?php
	$var1="First Name: " . $_POST["firstname"]."\r\n";
	$var2="Last Name: ". $_POST["lastname"]."\r\n";
	$var3="Gender: ". $_POST["gender"]."\r\n";
	$var4="Date of Birth: ".$_POST["Date"]."\r\n";
	$var5="Age(between 18 and 22): ".$_POST["age"]."\r\n";
	$var6="Email: ".$_POST["email"]."\r\n";
	$var7="Phone: ".$_POST["phone"]."\r\n";
	$var8="Linked In Profile: " .$_POST["linkedin"]."\r\n";
	$var9="Color: ".$_POST["color"]."\r\n";
	$var10="Degree: ".$_POST["vehicle"]."\r\n";
	$var11="		".$_POST["btech"]."\r\n";
	$var12="Degree:".$_POST["vehicle1"]."\r\n";
	$var13="		".$_POST["Mtech"]."\r\n";
	$var14="Area of Interest: ".$_POST["interest"]."\r\n";
	$var15="Experience: ".$_POST["experience"]."\r\n";
	$var16="JobTitle: ".$_POST["jobtitle"]."\r\n";
	$var17="Job Description: ".$_POST["jobdescription"]."\r\n";

	$myfile = fopen("newfile.txt", "w") or die("Unable to open file!");
	fwrite($myfile, $var1);
	fwrite($myfile, $var2);
	fwrite($myfile, $var3);
	fwrite($myfile, $var4);
	fwrite($myfile, $var5);
	fwrite($myfile, $var6);
	fwrite($myfile, $var7);
	fwrite($myfile, $var8);
	fwrite($myfile, $var9);
	fwrite($myfile, $var10);
	fwrite($myfile, $var11);
	fwrite($myfile, $var12);
	fwrite($myfile, $var13);
	fwrite($myfile, $var14);
	fwrite($myfile, $var15);
	fwrite($myfile, $var16);
	fwrite($myfile, $var17);
	fclose($myfile);

?>