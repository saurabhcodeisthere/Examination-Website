<?php
	include "index.php";
	$fname=$_POST['fname'];
	$lname=$_POST["lname"];
	$email=$_POST["email"];
	$password=$_POST["pass"];
	$gender=$_POST["gender"];
	$qualification=$_POST["qualification"];
	$contact=$_POST["contact"];
	global $conn;
	if(isset($_POST['submit']))
	{
		$stmt = $conn->prepare("INSERT INTO teachers_details (Fname,Lname,Email,Password,Gender,Qualification,Phone) VALUES (?,?,?,?,?,?,?)");
		echo $conn -> error;
    	$stmt->bind_param("ssssssi",$fname,$lname,$email,$password,$gender,$qualification,$contact);
    	$stmt->execute();
    	$stmt->close();
	}
	else
	{
		echo "Data not reached.Enter again.";
	}
	if(isset($_POST['submit']))
	{
		$stmt = $conn->prepare("INSERT INTO teachers
			_login (Email,Password) VALUES (?, ?)");
    	$stmt->bind_param("ss",$email,$password);
    	$stmt->execute();
    	$stmt->close();
	}
	else
	{
		echo "Data not reached.Enter again.";
	}

?>