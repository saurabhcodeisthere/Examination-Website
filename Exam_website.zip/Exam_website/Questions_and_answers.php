<?php
	include "index.php";
 	global $conn;
 	$answer_id;
 	$subjectid=$_POST["subject"];
	$question=$_POST["question"];
	$answers=$_POST["answers"];
	$option1=$_POST["option1"];
	$option2=$_POST["option2"];
	$option3=$_POST["option3"];
	$option4=$_POST["option4"];
	if(isset($_POST['add_question']))
	{
		$query="Insert into answer (Answer_Id,Option_A,Option_B,Option_C,Option_D,CorrectAnswer) values('','$option1','$option2','$option3','$option4','$answers')";
		$sql = "SELECT Answer_Id FROM answer WHERE Option_A='$option1' AND Option_B='$option2' AND Option_C='$option3'AND Option_D='$option4' AND CorrectAnswer='$answers'";
		
		if($conn->query($query))
 			echo'Data inserted successfully.';
 		else
 		{
 			echo'Try again.';
 			echo mysqli_error($conn);
 		}
 		$result=$conn->query($sql);
 		$followingdata = $result->fetch_array(MYSQLI_ASSOC);
		$answerid=$followingdata[Answer_Id];

		$query2="Insert into question (Question_Id,Questions,Subject_Id,Answer_Id) values('','$question','$subjectid','$answerid')";

		if($conn->query($query2))
			header('Location:PageTakingMCQ.php');
		else
			echo 'Try again';
	}
	if(isset($_POST['submit']))
	{
		header('Location:../html/frontPage.html');
	}
?>