<?php
 include "index.php";
 $email=$_POST["login"];
 $password=$_POST["password"];
 global $conn;
 global $pass;
 if(isset($_POST['submit']))
 {
 	$stmt=$conn->prepare("SELECT Password from teachers_login where Email=?");
 	$stmt->bind_param("s",$email);
 	$stmt->execute();
 	$stmt->store_result();
 	$stmt->bind_result($Password);
 	$stmt->fetch();
 	$pass=$Password;
 }
 else
 {
 	echo "Data connection failed.";
 }
 if($pass==$password)
 	header('Location:../html/subject.html');
 else
 	header('Location:../html/Teachers_login.html');
?>