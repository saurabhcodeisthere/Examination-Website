<?php 
	$var = 3;
?>
<script type="text/javascript">
	alert(</script><?php echo $var; ?> <script>);
</script>