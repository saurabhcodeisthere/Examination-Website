<?php
	include "index.php";
	$fname=$_POST['fname'];
	$lname=$_POST["lname"];
	$email=$_POST["email"];
	$password=$_POST["pass"];
	$contact=$_POST["contact"];
	global $conn;
	if(isset($_POST['submit']))
	{
		$stmt = $conn->prepare("INSERT INTO hoteldetails (Fname,Lname,Email,Password,Phone) VALUES (?,?,?,?,?)");
		echo $conn -> error;
    	$stmt->bind_param("ssssi",$fname,$lname,$email,$password,$contact);
    	$stmt->execute();
    	$stmt->close();
    	header("Location:../html/HotelLogin.html");
	}
	else
	{
		echo "Data not reached.Enter again.";
	}
?>