<?php
 include "index_pdo.php";
 $email=$_POST["login"];
 $password=$_POST["password"];
 global $conn;
 global $pass;
 if(isset($_POST['submit']))
 {
 	$stmt=$conn->prepare("SELECT Password from login where Email=:email");
 	$stmt->bind_param(:email,$email);
 	$stmt->execute();
 	$stmt->store_result();
 	$stmt->bind_result($Password);
 	$stmt->fetch();
 	$pass=$Password;
 }
 else
 {
 	echo "Data connection failed.";
 }
 if($pass==$password)
 	echo "Welcome";
 else
 	echo "OOps! wrong id or password.";
?>