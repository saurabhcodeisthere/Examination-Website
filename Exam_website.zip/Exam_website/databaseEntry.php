<?php
	include "index.php";
	$var1=$_POST["firstname"];
	$var2=$_POST["lastname"];
	$var3=$_POST["gender"];
	$var4=$_POST["Date"];
	$var5=$_POST["age"];
	$var6=$_POST["email"];
	$var7=$_POST["phone"];
	$var8=$_POST["linkedin"];
	$var9=$_POST["color"];
	$var10=$_POST["vehicle"];
	$var11=$_POST["btech"];
	$var12=$_POST["vehicle1"];
	$var13=$_POST["Mtech"];
	$var14=$_POST["interest"];
	$var15=$_POST["experience"];
	$var16=$_POST["jobtitle"];
	$var17=$_POST["jobdescription"];
	global $conn;
	if(isset($_POST['submit']))
	{
		$stmt = $conn->prepare("INSERT INTO form_det (Firstname,Lastname,gender,Date of birth,Age,E-mail,Personal Phone Number,Linked In profile,Color,Degree,Degree 1,Degree 2,Degree 3,Area of interest,Years of Experience,Job Title,Job Description) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
		echo $conn -> error;
    	$stmt->bind_param("ssssisissssssssss",$var1,$var2,$var3,$var4,$var5,$var6,$var7,$var8,$var9,$var10,$var11,$var12,$var13,$var14,$var15,$var16,$var17);
    	$stmt->execute();
    	$stmt->close();
	}
	else
	{
		echo "Data not reached.Enter again.";
	}