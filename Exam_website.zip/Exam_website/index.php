<?php
	$servername="localhost";
	$username="root";
	$password="";
	$dbname="exam_website";
	$conn=new mysqli($servername,$username,$password,$dbname);
?>