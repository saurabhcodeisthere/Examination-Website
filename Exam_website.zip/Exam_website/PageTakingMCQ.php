<DOCETYPE HTML>
	<HTML>
		<HEAD>
			<TITLE>Page which takes MCQ From User</TITLE>
			<script src=-"..\Javascript\jquery-3.4.1.js"></script>
			<script src=-"..\Javascript\PageTakingMCQ.js"></script>
			<link rel="stylesheet" type="text/css" href="..\css\PageTakingMCQ.css">
		</HEAD>
		<Body>
			<h1>Quiz Creator</h1>
			  <div class="addQuestions">
			  	<form class="login-form" id="myform" action="Questions_and_answers.php" method="POST">
			    	<input id="questionInput" type="text" placeholder="Question" name="question"><br>
			    	<input id="correctInput" type="text" placeholder="Correct Answer" name="answers"><br>
			    	<input id="wrongOneInput" type="text" placeholder="Option 1" name="option1"><br>
			    	<input id="wrongTwoInput" type="text" placeholder="Option 2" name="option2"><br>
			    	<input id="wrongThreeInput" type="text" placeholder="Option 3" name="option3"><br>
			    	<input id="wrongFourInput" type="text" placeholder="Option 4" name="option4"><br>
			    	<input id="subjectcode"type="hidden" name="subject" value="<?php echo $_GET["subject"]?>"><br>
			    	<button id="submit" name="add_question">Add Question</button><br><br><br>
			    	<button name="submit">Submit</button>
			    </form>
			  </div>
			  <p class="answersCorrect"></p>
			  <div class="questionsWrapper"></div>
			  <?php $_GET["subject"];?>
			  <script>
			  	function sub()
			  	{
			  		var subject = "<?php echo $_GET["subject"]?>";
			  		return subject;
			  	}
			  </script>
		</Body>
	</HTML>