 <?php
 include "index.php";
 global $conn;
 $sql="Insert into java (Item_name,Item_id,Exp_date,Shipped_Date,Price) values ('iugsdj','ugdiuh','gfsdytfh','jdfcsyv','hjvasdhf')";
 if($conn->query($sql))
 	echo'Data inserted successfully.';
 $result=$conn->query("select Item_name,Item_id,Exp_date,Company,Price from java");
 echo '<table border="0" cellspacing="2" cellpadding="2"> 
		      <tr> 
		          <td> <font face="Arial">Item Name</font> </td>
		          <td> <font face="Arial">Item Id</font> </td>
		          <td> <font face="Arial">Expiry Date</font> </td>
		          <td> <font face="Arial">Company</font> </td>
		          <td> <font face="Arial">Price</font> </td>
		      </tr>';

 if($result->num_rows>0)
 {
 	while($row=$result->fetch_assoc())
 	{
 		$var1=$row["Item_name"];
 		$var2=$row["Item_id"];
 		$var3=$row["Exp_date"];
 		$var4=$row["Company"];
 		$var5=$row["Price"];
 		echo '<tr> 
		           <td>'.$var1.'</td> 
		           <td>'.$var2.'</td>
		           <td>'.$var3.'</td>
		           <td>'.$var4.'</td>
		           <td>'.$var5.'</td>
		       </tr>';
 	}
 }
 ?>