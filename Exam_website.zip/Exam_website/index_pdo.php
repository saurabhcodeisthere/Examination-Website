<?php
	$servername="localhost";
	$username="root";
	$password="";
	$dbname="exam_website";
	$conn=new PDO('mysql:host=localhost;port=3306;dbname=exam_website','root','');
	//see the "errors" folder for details
	$conn->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);