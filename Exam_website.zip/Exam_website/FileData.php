<?php
	include "index.php";
	$var1=$_POST["keyword1"];
	$var2=$_POST["keyword2"];
	$var3=$_POST["keyword3"];
	$var4=$_POST["keyword4"];
	$var5=$_POST["keyword5"];
	$temp = explode(".", $_FILES["file"]["name"]);
	if ($_FILES["file"]["error"] > 0)
    {
    	echo "Return Code: " . $_FILES["file"]["error"] . "<br>";
    }
  	else
    {
    	echo "Upload: " . $_FILES["file"]["name"] . "<br>";
    	echo "Type: " . $_FILES["file"]["type"] . "<br>";
    	echo "Size: " . ($_FILES["file"]["size"] / 1024) . " kB<br>";
    	echo "Temp file: " . $_FILES["file"]["tmp_name"] . "<br>";

    	if (file_exists("Saved_File/" . $_FILES["file"]["name"]))
    	{
      		echo $_FILES["file"]["name"] . " already exists. ";
    	}
    	else
    	{
    		//$_FILES["file"]["name"]="checking";
      		move_uploaded_file($_FILES["file"]["tmp_name"],
      		"Saved_File/" . $_FILES["file"]["name"]);
      		echo "Stored in: " . "Saved_File/" . $_FILES["file"]["name"];
      		$var1=$_POST["keyword1"];
			$var2=$_POST["keyword2"];
			$var3=$_POST["keyword3"];
			$var4=$_POST["keyword4"];
			$var5=$_POST["keyword5"];
			$content=file_get_contents("newfile.txt");
			$count1=substr_count($content,$var1);
			$count2=substr_count($content,$var2);
			$count3=substr_count($content,$var3);
			$count4=substr_count($content,$var4);
			$count5=substr_count($content,$var5);
			echo '<table border="0" cellspacing="2" cellpadding="2"> 
		      <tr> 
		          <td> <font face="Arial">Word</font> </td> 
		          <td> <font face="Arial">Frequency</font> </td> 
		      </tr>';

		       echo '<tr> 
		                  <td>'.$var1.'</td> 
		                  <td>'.$count1.'</td>  
		              </tr>';
		       echo '<tr> 
		                  <td>'.$var2.'</td> 
		                  <td>'.$count2.'</td>  
		              </tr>';
		       echo '<tr> 
		                  <td>'.$var3.'</td> 
		                  <td>'.$count3.'</td>  
		              </tr>';
		       echo '<tr> 
		                  <td>'.$var4.'</td> 
		                  <td>'.$count4.'</td>  
		              </tr>';
		       echo '<tr> 
		                  <td>'.$var5.'</td> 
		                  <td>'.$count5.'</td>  
		              </tr>';
    	}
    }
?>